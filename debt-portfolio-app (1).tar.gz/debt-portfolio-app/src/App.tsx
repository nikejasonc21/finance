import React from 'react';
import { Instrument } from './types/instrument';
import { InterestScenario } from './types/scenario';
import { InterestRow, calculateInterest } from './utils/interestCalculator';
import { defaultPortfolio } from './data/defaultPortfolio';
import UploadPortfolio from './components/UploadPortfolio';
import InstrumentForm from './components/InstrumentForm';
import ScenarioSelector from './components/ScenarioSelector';
import InterestSummary from './components/InterestSummary';
import MaturityLadder from './components/MaturityLadder';
import LeverageInput from './components/LeverageInput';
import LeverageSummary from './components/LeverageSummary';
import { LeverageResult } from './utils/leverageCalculator';

const App: React.FC = () => {
  const [instruments, setInstruments] = React.useState<Instrument[]>(defaultPortfolio);
  const [projectionYears, setProjectionYears] = React.useState<number>(5);
  const [scenario, setScenario] = React.useState<InterestScenario>({ type: 'flat', flatRate: 0.05 });
  const [filterEntity, setFilterEntity] = React.useState<string | null>(null);
  const [interestRows, setInterestRows] = React.useState<InterestRow[]>([]);
  const [leverageResults, setLeverageResults] = React.useState<LeverageResult[]>([]);

  // Compute interest forecast whenever dependencies change
  React.useEffect(() => {
    const rows = calculateInterest(instruments, scenario, projectionYears, filterEntity);
    setInterestRows(rows);
  }, [instruments, scenario, projectionYears, filterEntity]);

  // Determine unique entities for dropdown
  const entities = React.useMemo(() => {
    return Array.from(new Set(instruments.map((inst) => inst.entity)));
  }, [instruments]);

  // Handle instrument upload by replacing or appending to existing instruments
  const handleUpload = (data: Instrument[]) => {
    setInstruments(data);
  };

  const handleAddInstrument = (inst: Instrument) => {
    setInstruments((prev) => [...prev, inst]);
  };

  const resetModel = () => {
    setInstruments(defaultPortfolio);
    setProjectionYears(5);
    setScenario({ type: 'flat', flatRate: 0.05 });
    setFilterEntity(null);
    setLeverageResults([]);
  };

  // Download results as CSV
  const downloadResults = () => {
    // Build CSV header
    const headers = ['Year', 'Total Interest', ...entities];
    const lines = [headers.join(',')];
    interestRows.forEach((row) => {
      const parts = [row.year.toString(), row.total.toString()];
      entities.forEach((entity) => {
        parts.push(row.breakdown[entity]?.toString() ?? '0');
      });
      lines.push(parts.join(','));
    });
    const csvContent = lines.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'interest_results.csv';
    link.click();
  };

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow p-4">
        <h1 className="text-2xl font-bold">Debt Portfolio Modeling Tool</h1>
      </header>
      <main className="flex-1 flex flex-col md:flex-row">
        {/* Left panel: Inputs */}
        <aside className="md:w-1/3 p-4 space-y-6 border-r border-gray-200 bg-white">
          <section>
            <h2 className="text-lg font-semibold mb-2">Portfolio</h2>
            <UploadPortfolio onUpload={handleUpload} templateCsv={
              'entity,type,notional,rate,spread,maturityYear\n' +
              'Entity A,floating,10000000,0,0.02,2027\n' +
              'Entity A,fixed,5000000,0.05,0,2030\n' +
              'Entity B,floating,8000000,0,0.015,2026\n' +
              'Entity B,fixed,4000000,0.045,0,2029\n'
            } />
            <InstrumentForm onAdd={handleAddInstrument} />
          </section>
          <section>
            <h2 className="text-lg font-semibold mb-2">Interest Model</h2>
            <div className="flex flex-col space-y-3">
              <div className="flex flex-col space-y-1">
                <label className="text-sm font-medium" htmlFor="years">
                  Projection Years
                </label>
                <input
                  id="years"
                  type="number"
                  min="1"
                  max="30"
                  className="p-2 border rounded w-24"
                  value={projectionYears}
                  onChange={(e) => setProjectionYears(parseInt(e.target.value, 10))}
                />
              </div>
              <ScenarioSelector scenario={scenario} onScenarioChange={setScenario} />
              <div className="flex flex-col space-y-1">
                <label className="text-sm font-medium" htmlFor="entityFilter">
                  Entity Filter
                </label>
                <select
                  id="entityFilter"
                  className="p-2 border rounded w-40"
                  value={filterEntity ?? ''}
                  onChange={(e) => {
                    const val = e.target.value;
                    setFilterEntity(val === '' ? null : val);
                  }}
                >
                  <option value="">All</option>
                  {entities.map((entity) => (
                    <option key={entity} value={entity}>
                      {entity}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => {
                    const rows = calculateInterest(instruments, scenario, projectionYears, filterEntity);
                    setInterestRows(rows);
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                >
                  Run Model
                </button>
                <button
                  type="button"
                  onClick={resetModel}
                  className="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400"
                >
                  Reset Model
                </button>
                <button
                  type="button"
                  onClick={downloadResults}
                  className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
                >
                  Download Results
                </button>
              </div>
            </div>
          </section>
          <section>
            <h2 className="text-lg font-semibold mb-2">Leverage Sensitivity</h2>
            <LeverageInput onCalculate={setLeverageResults} />
          </section>
        </aside>
        {/* Right panel: Outputs */}
        <section className="flex-1 p-4 space-y-8 overflow-y-auto">
          <InterestSummary rows={interestRows} showBreakdown={!filterEntity} />
          <MaturityLadder instruments={instruments} showBreakdown={!filterEntity} filterEntity={filterEntity} />
          {leverageResults.length > 0 && <LeverageSummary results={leverageResults} />}
        </section>
      </main>
      <footer className="p-4 text-center text-xs text-gray-600 bg-white border-t border-gray-200">
        © {new Date().getFullYear()} Debt Portfolio Modeling Tool
      </footer>
    </div>
  );
};

export default App;
