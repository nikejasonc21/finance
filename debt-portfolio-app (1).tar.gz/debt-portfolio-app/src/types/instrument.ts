export type DebtType = 'fixed' | 'floating';

/**
 * Represents a single debt instrument in the portfolio.
 */
export interface Instrument {
  /** Unique identifier for the instrument. */
  id: string;
  /** Name of the borrowing entity (company, business unit, etc.). */
  entity: string;
  /** Debt type: fixed or floating. */
  type: DebtType;
  /** Principal amount outstanding. */
  notional: number;
  /** Coupon or base rate for fixed instruments. */
  rate: number;
  /** Spread above base rate for floating instruments. */
  spread: number;
  /** Year when the instrument matures (e.g. 2027). */
  maturityYear: number;
}
