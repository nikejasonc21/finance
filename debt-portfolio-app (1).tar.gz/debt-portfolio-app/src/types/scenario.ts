/**
 * Defines the available interest rate scenarios for the model.
 */
export type ScenarioType = 'flat' | 'treasury';

/**
 * Parameters for the flat interest scenario.
 */
export interface FlatScenario {
  type: 'flat';
  /** Base rate applied across all projection years. */
  flatRate: number;
}

/**
 * Parameters for the treasury curve scenario.
 */
export interface TreasuryScenario {
  type: 'treasury';
  /**
   * Mapping between projection year offsets (e.g. year 0, 1, 2) and the
   * associated market rate for that year. Year 0 refers to the first year
   * of the forecast.
   */
  curve: Record<number, number>;
}

/**
 * Union of possible interest scenarios.
 */
export type InterestScenario = FlatScenario | TreasuryScenario;
