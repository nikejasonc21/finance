import React from 'react';
import { LeverageResult } from '../utils/leverageCalculator';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from 'recharts';

interface LeverageSummaryProps {
  results: LeverageResult[];
}

/**
 * Displays leverage sensitivity results as a table and line chart. Each row shows
 * the interest rate shift (bps) and the resulting ROE. The chart visualizes
 * ROE across the shift range.
 */
const LeverageSummary: React.FC<LeverageSummaryProps> = ({ results }) => {
  const formatPercent = (value: number) => {
    return (value * 100).toFixed(2) + '%';
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Leverage Sensitivity</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm text-gray-800">
          <thead>
            <tr className="bg-gray-100">
              <th className="py-2 px-4 text-left">Shift (bps)</th>
              <th className="py-2 px-4 text-right">ROE</th>
            </tr>
          </thead>
          <tbody>
            {results.map((row) => (
              <tr key={row.shiftBps} className="border-b border-gray-200">
                <td className="py-2 px-4 font-medium">{row.shiftBps}</td>
                <td className="py-2 px-4 text-right">{formatPercent(row.roe)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{ width: '100%', height: 350 }}>
        <ResponsiveContainer>
          <LineChart data={results} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="shiftBps" label={{ value: 'Shift (bps)', position: 'insideBottom', offset: -5 }} />
            <YAxis tickFormatter={(value) => `${(value * 100).toFixed(1)}%`} label={{ value: 'ROE', angle: -90, position: 'insideLeft', offset: 10 }} />
            <Tooltip formatter={(value: number) => `${(value * 100).toFixed(2)}%`} />
            <Line type="monotone" dataKey="roe" stroke="#E53E3E" dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default LeverageSummary;
