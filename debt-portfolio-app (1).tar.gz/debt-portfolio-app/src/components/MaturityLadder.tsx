import React from 'react';
import { Instrument } from '../types/instrument';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface MaturityLadderProps {
  instruments: Instrument[];
  /** Whether to display entity-level breakdown in the table and chart. */
  showBreakdown?: boolean;
  /** Optional filter to include only one entity. */
  filterEntity?: string | null;
}

/**
 * Displays a summary of notional amounts maturing each year. A stacked bar chart and
 * accompanying table help visualize how maturities are distributed across the
 * projection horizon.
 */
const MaturityLadder: React.FC<MaturityLadderProps> = ({ instruments, showBreakdown = false, filterEntity }) => {
  // Build a map from year to notional by entity
  const maturityMap: Record<number, Record<string, number>> = {};
  instruments.forEach((inst) => {
    if (filterEntity && inst.entity !== filterEntity) return;
    const year = inst.maturityYear;
    maturityMap[year] = maturityMap[year] || {};
    const entity = inst.entity;
    maturityMap[year][entity] = (maturityMap[year][entity] || 0) + inst.notional;
  });
  const years = Object.keys(maturityMap)
    .map((y) => parseInt(y, 10))
    .sort((a, b) => a - b);
  const entities = Array.from(
    new Set(
      instruments
        .filter((inst) => !filterEntity || inst.entity === filterEntity)
        .map((inst) => inst.entity)
    )
  );
  // Build data for chart and table
  const data = years.map((year) => {
    const entry: any = { year: year.toString(), total: 0 };
    entities.forEach((entity) => {
      const notional = maturityMap[year][entity] || 0;
      entry[entity] = notional;
      entry.total += notional;
    });
    return entry;
  });

  // Format numbers with thousands separators
  const formatCurrency = (value: number) => {
    return value.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Maturity Ladder</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm text-gray-800">
          <thead>
            <tr className="bg-gray-100">
              <th className="py-2 px-4 text-left">Year</th>
              <th className="py-2 px-4 text-right">Total Notional</th>
              {showBreakdown &&
                entities.map((entity) => (
                  <th key={entity} className="py-2 px-4 text-right">
                    {entity}
                  </th>
                ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row) => (
              <tr key={row.year} className="border-b border-gray-200">
                <td className="py-2 px-4 font-medium">{row.year}</td>
                <td className="py-2 px-4 text-right">${formatCurrency(row.total)}</td>
                {showBreakdown &&
                  entities.map((entity) => (
                    <td key={entity} className="py-2 px-4 text-right">
                      {row[entity] ? `$${formatCurrency(row[entity])}` : '-'}
                    </td>
                  ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{ width: '100%', height: 350 }}>
        <ResponsiveContainer>
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <XAxis dataKey="year" />
            <YAxis tickFormatter={(value) => `$${formatCurrency(value as number)}`}
              label={{ value: 'Notional', angle: -90, position: 'insideLeft', offset: 10 }}
            />
            <Tooltip formatter={(value: number) => `$${formatCurrency(value)}`} />
            <Legend />
            {showBreakdown ? (
              entities.map((entity, index) => (
                <Bar
                  key={entity}
                  dataKey={entity}
                  name={entity}
                  stackId="a"
                  fill={['#4299E1', '#9F7AEA', '#F6AD55', '#48BB78'][index % 4]}
                />
              ))
            ) : (
              <Bar dataKey="total" name="Total" fill="#F6AD55" />
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default MaturityLadder;
