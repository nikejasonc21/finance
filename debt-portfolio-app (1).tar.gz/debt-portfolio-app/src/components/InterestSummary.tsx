import React from 'react';
import { InterestRow } from '../utils/interestCalculator';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface InterestSummaryProps {
  rows: InterestRow[];
  /** Whether to display entity-level breakdown in the table and chart. */
  showBreakdown?: boolean;
}

/**
 * Displays a summary of interest expense by year. When showBreakdown is true, the
 * chart and table include separate series/columns for each entity. Otherwise, only
 * the total interest is shown.
 */
const InterestSummary: React.FC<InterestSummaryProps> = ({ rows, showBreakdown = false }) => {
  // Determine unique entities across all rows
  const entities = React.useMemo(() => {
    const set = new Set<string>();
    if (showBreakdown) {
      rows.forEach((row) => {
        Object.keys(row.breakdown).forEach((entity) => set.add(entity));
      });
    }
    return Array.from(set);
  }, [rows, showBreakdown]);

  // Create data for charts: year label and series values
  const chartData = rows.map((row) => {
    const entry: any = { year: row.year.toString(), total: row.total };
    if (showBreakdown) {
      entities.forEach((entity) => {
        entry[entity] = row.breakdown[entity] ?? 0;
      });
    }
    return entry;
  });

  // Format numbers with thousands separators and millions for readability
  const formatCurrency = (value: number) => {
    return value.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Interest Forecast</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm text-gray-800">
          <thead>
            <tr className="bg-gray-100">
              <th className="py-2 px-4 text-left">Year</th>
              <th className="py-2 px-4 text-right">Total Interest</th>
              {showBreakdown &&
                entities.map((entity) => (
                  <th key={entity} className="py-2 px-4 text-right">
                    {entity}
                  </th>
                ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.year} className="border-b border-gray-200">
                <td className="py-2 px-4 font-medium">{row.year}</td>
                <td className="py-2 px-4 text-right">${formatCurrency(row.total)}</td>
                {showBreakdown &&
                  entities.map((entity) => (
                    <td key={entity} className="py-2 px-4 text-right">
                      {row.breakdown[entity] ? `$${formatCurrency(row.breakdown[entity])}` : '-'}
                    </td>
                  ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div style={{ width: '100%', height: 350 }}>
        <ResponsiveContainer>
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <XAxis dataKey="year" />
            <YAxis tickFormatter={(value) => `$${formatCurrency(value as number)}`}
              label={{ value: 'Interest', angle: -90, position: 'insideLeft', offset: 10 }}
            />
            <Tooltip formatter={(value: number) => `$${formatCurrency(value)}`} />
            <Legend />
            {showBreakdown ? (
              entities.map((entity, index) => (
                <Bar
                  key={entity}
                  dataKey={entity}
                  name={entity}
                  stackId="a"
                  fill={['#4299E1', '#9F7AEA', '#F6AD55', '#48BB78'][index % 4]}
                />
              ))
            ) : (
              <Bar dataKey="total" name="Total" fill="#4299E1" />
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default InterestSummary;
