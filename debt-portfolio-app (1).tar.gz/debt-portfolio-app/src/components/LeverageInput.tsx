import React from 'react';
import { calculateLeverageSeries, LeverageResult } from '../utils/leverageCalculator';

interface LeverageInputProps {
  onCalculate: (results: LeverageResult[]) => void;
}

/**
 * Form allowing users to specify leverage assumptions and run a sensitivity analysis.
 * Inputs include leverage ratio, return on assets, base cost of debt, and a range of
 * interest rate shifts (in basis points). Upon submission, the calculated ROE
 * series is returned via the onCalculate callback.
 */
const LeverageInput: React.FC<LeverageInputProps> = ({ onCalculate }) => {
  const [leverage, setLeverage] = React.useState(3);
  const [roa, setRoa] = React.useState(8); // percentage
  const [baseCost, setBaseCost] = React.useState(5); // percentage
  const [startShift, setStartShift] = React.useState(-200);
  const [endShift, setEndShift] = React.useState(200);
  const [step, setStep] = React.useState(50);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const results = calculateLeverageSeries(
      leverage,
      roa / 100,
      baseCost / 100,
      startShift,
      endShift,
      step
    );
    onCalculate(results);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex flex-col space-y-1">
        <label className="text-sm font-medium" htmlFor="leverage">
          Leverage Ratio (x)
        </label>
        <input
          id="leverage"
          type="number"
          step="0.1"
          min="0"
          className="p-2 border rounded w-40"
          value={leverage}
          onChange={(e) => setLeverage(parseFloat(e.target.value))}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label className="text-sm font-medium" htmlFor="roa">
          Return on Assets (%)
        </label>
        <input
          id="roa"
          type="number"
          step="0.1"
          className="p-2 border rounded w-40"
          value={roa}
          onChange={(e) => setRoa(parseFloat(e.target.value))}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label className="text-sm font-medium" htmlFor="baseCost">
          Base Rate + Spread (%)
        </label>
        <input
          id="baseCost"
          type="number"
          step="0.1"
          className="p-2 border rounded w-40"
          value={baseCost}
          onChange={(e) => setBaseCost(parseFloat(e.target.value))}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label className="text-sm font-medium" htmlFor="startShift">
          Rate Shift Start (bps)
        </label>
        <input
          id="startShift"
          type="number"
          step="25"
          className="p-2 border rounded w-40"
          value={startShift}
          onChange={(e) => setStartShift(parseInt(e.target.value, 10))}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label className="text-sm font-medium" htmlFor="endShift">
          Rate Shift End (bps)
        </label>
        <input
          id="endShift"
          type="number"
          step="25"
          className="p-2 border rounded w-40"
          value={endShift}
          onChange={(e) => setEndShift(parseInt(e.target.value, 10))}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label className="text-sm font-medium" htmlFor="step">
          Step Size (bps)
        </label>
        <input
          id="step"
          type="number"
          step="25"
          min="1"
          className="p-2 border rounded w-40"
          value={step}
          onChange={(e) => setStep(parseInt(e.target.value, 10))}
        />
      </div>
      <button
        type="submit"
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Run Sensitivity
      </button>
    </form>
  );
};

export default LeverageInput;
