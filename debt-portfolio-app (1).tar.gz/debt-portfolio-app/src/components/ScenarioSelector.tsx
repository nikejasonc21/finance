import React from 'react';
import Papa from 'papaparse';
import {
  InterestScenario,
  FlatScenario,
  TreasuryScenario,
} from '../types/scenario';

interface ScenarioSelectorProps {
  scenario: InterestScenario;
  onScenarioChange: (scenario: InterestScenario) => void;
}

/**
 * Component allowing the user to choose between a flat or treasury interest scenario.
 * When the flat scenario is selected, a numeric input for the base rate is displayed.
 * When the treasury scenario is selected, a file input appears for uploading a curve CSV.
 */
const ScenarioSelector: React.FC<ScenarioSelectorProps> = ({ scenario, onScenarioChange }) => {
  const handleFlatRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    const flat: FlatScenario = { type: 'flat', flatRate: value / 100 };
    onScenarioChange(flat);
  };

  const handleFileChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result as string;
      // Expect CSV with headers: year,rate
      const parsed = Papa.parse<Record<string, string>>(text, {
        header: true,
        skipEmptyLines: true,
      });
      // Determine the base year from the first row
      let baseYear: number | null = null;
      const curve: Record<number, number> = {};
      parsed.data.forEach((row) => {
        const year = parseInt(row.year ?? row.maturityYear ?? '', 10);
        const rate = parseFloat(row.rate ?? row.value ?? '0') / 100;
        if (!isNaN(year) && !isNaN(rate)) {
          if (baseYear === null) baseYear = year;
          const offset = year - (baseYear ?? year);
          curve[offset] = rate;
        }
      });
      const tre: TreasuryScenario = { type: 'treasury', curve };
      onScenarioChange(tre);
    };
    reader.onerror = (err) => {
      console.error('Failed to read curve file', err);
      alert('Failed to read curve CSV. Ensure it contains year and rate columns.');
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center space-x-4">
        <label className="inline-flex items-center cursor-pointer">
          <input
            type="radio"
            name="scenario"
            className="mr-2"
            checked={scenario.type === 'flat'}
            onChange={() => onScenarioChange({ type: 'flat', flatRate: 0.05 })}
          />
          <span>Flat Interest</span>
        </label>
        <label className="inline-flex items-center cursor-pointer">
          <input
            type="radio"
            name="scenario"
            className="mr-2"
            checked={scenario.type === 'treasury'}
            onChange={() => onScenarioChange({ type: 'treasury', curve: { 0: 0.05 } })}
          />
          <span>Treasury Curve</span>
        </label>
      </div>
      {scenario.type === 'flat' && (
        <div className="flex flex-col space-y-1">
          <label className="text-sm font-medium" htmlFor="flatRate">
            Flat Rate (%)
          </label>
          <input
            id="flatRate"
            type="number"
            step="0.01"
            className="p-2 border rounded w-40"
            value={(scenario.flatRate * 100).toString()}
            onChange={handleFlatRateChange}
          />
        </div>
      )}
      {scenario.type === 'treasury' && (
        <div className="flex flex-col space-y-1">
          <label className="text-sm font-medium" htmlFor="curveFile">
            Upload Market Curve (CSV)
          </label>
          <input
            id="curveFile"
            type="file"
            accept=".csv"
            className="p-2 border rounded w-64"
            onChange={handleFileChange}
          />
        </div>
      )}
    </div>
  );
};

export default ScenarioSelector;
