import React from 'react';
import { Instrument, DebtType } from '../types/instrument';

interface InstrumentFormProps {
  onAdd: (instrument: Instrument) => void;
}

const InstrumentForm: React.FC<InstrumentFormProps> = ({ onAdd }) => {
  const [entity, setEntity] = React.useState('');
  const [type, setType] = React.useState<DebtType>('fixed');
  const [notional, setNotional] = React.useState<number>(0);
  const [rate, setRate] = React.useState<number>(0);
  const [spread, setSpread] = React.useState<number>(0);
  const [maturityYear, setMaturityYear] = React.useState<number>(new Date().getFullYear());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Basic id generation using timestamp
    const id = `${entity}-${Date.now()}`;
    onAdd({ id, entity, type, notional, rate, spread, maturityYear });
    // reset form
    setEntity('');
    setType('fixed');
    setNotional(0);
    setRate(0);
    setSpread(0);
    setMaturityYear(new Date().getFullYear());
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <h3 className="text-lg font-semibold">Add Instrument</h3>
      <div className="flex flex-col space-y-1">
        <label htmlFor="entity" className="text-sm font-medium">Entity</label>
        <input
          id="entity"
          type="text"
          className="p-2 border rounded"
          value={entity}
          onChange={(e) => setEntity(e.target.value)}
          required
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label htmlFor="type" className="text-sm font-medium">Type</label>
        <select
          id="type"
          className="p-2 border rounded"
          value={type}
          onChange={(e) => setType(e.target.value as DebtType)}
        >
          <option value="fixed">Fixed</option>
          <option value="floating">Floating</option>
        </select>
      </div>
      <div className="flex flex-col space-y-1">
        <label htmlFor="notional" className="text-sm font-medium">Notional</label>
        <input
          id="notional"
          type="number"
          step="1000"
          className="p-2 border rounded"
          value={notional}
          onChange={(e) => setNotional(parseFloat(e.target.value))}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label htmlFor="rate" className="text-sm font-medium">Rate (%)</label>
        <input
          id="rate"
          type="number"
          step="0.01"
          className="p-2 border rounded"
          value={rate}
          onChange={(e) => setRate(parseFloat(e.target.value) / 100)}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label htmlFor="spread" className="text-sm font-medium">Spread (%) (for floating)</label>
        <input
          id="spread"
          type="number"
          step="0.01"
          className="p-2 border rounded"
          value={spread}
          onChange={(e) => setSpread(parseFloat(e.target.value) / 100)}
        />
      </div>
      <div className="flex flex-col space-y-1">
        <label htmlFor="maturityYear" className="text-sm font-medium">Maturity Year</label>
        <input
          id="maturityYear"
          type="number"
          className="p-2 border rounded"
          value={maturityYear}
          onChange={(e) => setMaturityYear(parseInt(e.target.value, 10))}
        />
      </div>
      <button
        type="submit"
        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
      >
        Add Instrument
      </button>
    </form>
  );
};

export default InstrumentForm;
