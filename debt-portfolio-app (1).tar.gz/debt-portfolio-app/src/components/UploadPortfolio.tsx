import React from 'react';
import { Instrument } from '../types/instrument';
import { loadPortfolioFromCSV, parsePortfolioCSV } from '../utils/loadPortfolioFromCSV';

interface UploadPortfolioProps {
  /** Callback invoked with parsed instruments when user uploads a CSV. */
  onUpload: (instruments: Instrument[]) => void;
  /** Optional sample CSV text to provide a downloadable template. */
  templateCsv?: string;
}

/**
 * File input component that allows the user to upload a CSV portfolio. When a file is
 * selected, it is parsed and the resulting instruments are passed to the callback.
 */
const UploadPortfolio: React.FC<UploadPortfolioProps> = ({ onUpload, templateCsv }) => {
  const fileInputRef = React.useRef<HTMLInputElement | null>(null);

  const handleFileChange = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      try {
        const instruments = await loadPortfolioFromCSV(file);
        onUpload(instruments);
      } catch (err) {
        console.error('Failed to load CSV', err);
        alert('Failed to load CSV file. Please ensure it is correctly formatted.');
      } finally {
        // Reset input value to allow re-uploading the same file
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    }
  };

  const downloadTemplate = () => {
    if (!templateCsv) return;
    const blob = new Blob([templateCsv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'portfolio_template.csv';
    link.click();
  };

  return (
    <div className="space-y-2">
      <label className="block">
        <span className="sr-only">Upload CSV</span>
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
      </label>
      {templateCsv && (
        <button
          type="button"
          onClick={downloadTemplate}
          className="text-sm text-blue-600 hover:underline"
        >
          Download CSV template
        </button>
      )}
    </div>
  );
};

export default UploadPortfolio;
