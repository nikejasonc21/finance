import { Instrument } from '../types/instrument';

/**
 * A small mock portfolio used as the default dataset. Users can upload their
 * own CSV to replace or extend this data.
 */
export const defaultPortfolio: Instrument[] = [
  {
    id: '1',
    entity: 'Entity A',
    type: 'floating',
    notional: 10000000,
    rate: 0,
    spread: 0.02,
    maturityYear: 2027,
  },
  {
    id: '2',
    entity: 'Entity A',
    type: 'fixed',
    notional: 5000000,
    rate: 0.05,
    spread: 0,
    maturityYear: 2030,
  },
  {
    id: '3',
    entity: 'Entity B',
    type: 'floating',
    notional: 8000000,
    rate: 0,
    spread: 0.015,
    maturityYear: 2026,
  },
  {
    id: '4',
    entity: 'Entity B',
    type: 'fixed',
    notional: 4000000,
    rate: 0.045,
    spread: 0,
    maturityYear: 2029,
  },
];
