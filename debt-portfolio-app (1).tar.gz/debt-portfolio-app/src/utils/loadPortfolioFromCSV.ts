import Papa from 'papaparse';
import { Instrument, DebtType } from '../types/instrument';

/**
 * Parses a CSV string into an array of Instrument objects.
 * Expected columns: entity,type,notional,rate,spread,maturityYear
 *
 * @param csvText The raw CSV data as a string.
 */
export function parsePortfolioCSV(csvText: string): Instrument[] {
  const results: Instrument[] = [];
  const parsed = Papa.parse<Record<string, string>>(csvText, {
    header: true,
    skipEmptyLines: true,
  });
  if (parsed.errors && parsed.errors.length > 0) {
    console.warn('CSV parsing errors', parsed.errors);
  }
  parsed.data.forEach((row, idx) => {
    // Basic validation and conversion.
    const id = `${row.entity || 'Unknown'}-${idx}`;
    const entity = row.entity?.trim() ?? 'Unknown';
    const type = (row.type?.trim().toLowerCase() as DebtType) ?? 'fixed';
    const notional = parseFloat(row.notional ?? '0') || 0;
    const rate = parseFloat(row.rate ?? '0') || 0;
    const spread = parseFloat(row.spread ?? '0') || 0;
    const maturityYear = parseInt(row.maturityYear ?? '0', 10) || new Date().getFullYear();
    results.push({ id, entity, type, notional, rate, spread, maturityYear });
  });
  return results;
}

/**
 * Helper to read a file and parse its contents into Instruments.
 *
 * @param file File selected by the user through an <input type="file">.
 */
export async function loadPortfolioFromCSV(file: File): Promise<Instrument[]> {
  const reader = new FileReader();
  return new Promise((resolve, reject) => {
    reader.onload = () => {
      try {
        const text = reader.result as string;
        const instruments = parsePortfolioCSV(text);
        resolve(instruments);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = err => reject(err);
    reader.readAsText(file);
  });
}
