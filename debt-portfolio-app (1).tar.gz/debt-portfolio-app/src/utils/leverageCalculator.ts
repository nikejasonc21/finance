/**
 * Defines a single leverage sensitivity result.
 */
export interface LeverageResult {
  /** Interest rate shift in basis points. */
  shiftBps: number;
  /** Resulting return on equity. */
  roe: number;
}

/**
 * Computes a series of ROE values across a range of interest rate shifts.
 *
 * The cost of debt is assumed to be the provided baseCost (base rate + spread) plus
 * the shift (converted from basis points to a decimal rate). For each shift, ROE is
 * calculated as:
 *   ROE = ROA + L * (ROA - costOfDebt)
 *
 * @param leverage Leverage ratio (e.g. 3 means 3x)
 * @param roa Return on assets (decimal, e.g. 0.08 for 8%)
 * @param baseCost Base cost of debt (base rate + spread) in decimal form
 * @param startBps Starting shift in basis points (e.g. -200)
 * @param endBps Ending shift in basis points (e.g. 200)
 * @param stepBps Step size in basis points (e.g. 25)
 */
export function calculateLeverageSeries(
  leverage: number,
  roa: number,
  baseCost: number,
  startBps: number,
  endBps: number,
  stepBps: number = 25
): LeverageResult[] {
  const results: LeverageResult[] = [];
  for (let bps = startBps; bps <= endBps; bps += stepBps) {
    const shiftRate = bps / 10000; // convert bps to decimal
    const costOfDebt = baseCost + shiftRate;
    const roe = roa + leverage * (roa - costOfDebt);
    results.push({ shiftBps: bps, roe });
  }
  return results;
}
