import { Instrument } from '../types/instrument';
import { InterestScenario } from '../types/scenario';

export interface InterestRow {
  /** Projection year as an absolute year (e.g. 2025). */
  year: number;
  /** Total interest expense for all instruments in that year. */
  total: number;
  /** Optional breakdown of interest by entity. */
  breakdown: Record<string, number>;
}

/**
 * Computes annual interest expenses over the projection horizon given a set of instruments
 * and a chosen interest scenario. Interest is calculated on the full notional until the
 * instrument's maturity year, after which it contributes nothing.
 *
 * @param instruments Portfolio instruments
 * @param scenario Interest rate assumptions
 * @param projectionYears Number of years to project
 * @param filterEntity Optional filter to include only one entity
 */
export function calculateInterest(
  instruments: Instrument[],
  scenario: InterestScenario,
  projectionYears: number,
  filterEntity?: string | null
): InterestRow[] {
  const currentYear = new Date().getFullYear();
  const rows: InterestRow[] = [];
  for (let i = 0; i < projectionYears; i++) {
    const year = currentYear + i;
    let total = 0;
    const breakdown: Record<string, number> = {};
    instruments.forEach((inst) => {
      if (filterEntity && inst.entity !== filterEntity) return;
      // Only include instruments that haven't matured by this year
      if (year > inst.maturityYear) return;
      let rate = 0;
      if (inst.type === 'fixed') {
        rate = inst.rate;
      } else {
        // floating
        if (scenario.type === 'flat') {
          rate = scenario.flatRate + inst.spread;
        } else {
          // treasury curve: use year offset; default to last available curve point or 0
          const offset = i;
          if (scenario.curve.hasOwnProperty(offset)) {
            rate = scenario.curve[offset] + inst.spread;
          } else {
            const maxOffset = Math.max(
              ...Object.keys(scenario.curve).map((k) => parseInt(k, 10))
            );
            rate = (scenario.curve[maxOffset] ?? 0) + inst.spread;
          }
        }
      }
      const interest = inst.notional * rate;
      total += interest;
      breakdown[inst.entity] = (breakdown[inst.entity] || 0) + interest;
    });
    rows.push({ year, total, breakdown });
  }
  return rows;
}
